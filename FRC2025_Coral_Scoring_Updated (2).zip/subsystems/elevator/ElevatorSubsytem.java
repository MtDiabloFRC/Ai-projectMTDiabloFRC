// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems.elevator;

import frc.robot.Constants;
import frc.robot.Constants.ElevatorConstants;

import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkBase;
import com.revrobotics.spark.SparkBase.PersistMode;
import com.revrobotics.spark.config.AlternateEncoderConfig;
import com.revrobotics.spark.config.EncoderConfig;
import com.revrobotics.spark.config.SparkBaseConfig;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.thethriftybot.ThriftyNova.PIDConfig;
import com.revrobotics.spark.SparkFlex;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.servohub.ServoHub.ResetMode;
import com.revrobotics.servohub.config.ServoHubParameter;
import com.revrobotics.sim.SparkMaxAlternateEncoderSim;
import com.revrobotics.spark.SparkClosedLoopController;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

import frc.robot.RobotContainer;
import swervelib.encoders.SparkMaxEncoderSwerve;

import com.ctre.phoenix6.hardware.CANcoder;
//Encoder Imports
import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.spark.SparkMaxAlternateEncoder;
import com.revrobotics.spark.SparkClosedLoopController;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.math.trajectory.TrapezoidProfile;
import edu.wpi.first.wpilibj.DigitalInput;
import com.revrobotics.spark.SparkClosedLoopController;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.revrobotics.spark.config.ClosedLoopConfig.FeedbackSensor;
import com.revrobotics.spark.config.SparkBaseConfig.IdleMode;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkBase.ControlType;
import com.revrobotics.spark.SparkBase.PersistMode;
import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkLowLevel.MotorType;

//Encoder Math
import java.math.*;


public class ElevatorSubsytem extends SubsystemBase  {
  //Elevator Motor Controllers Declaration 
   public static SparkMax m_sparkElevatorLeft;
   public SparkMax m_sparkElevatorRight;

  //Elevator Encoder Declaration
   public static RelativeEncoder m_SparkMaxElevatorEncoder; 
  
  //PID Controller Declaration
   PIDController m_PidElevatorController;

  /** Creates a new Elevator Subsystem. */
  public ElevatorSubsytem() {
    
  //Motor Controller Initialization In Elevator Subsystem
    m_sparkElevatorLeft = new SparkMax(ElevatorConstants.elevator_SparkLeftID, MotorType.kBrushless);
    m_sparkElevatorRight = new SparkMax(ElevatorConstants.elevator_SparkRightID, MotorType.kBrushless);

  //Elevator Encoder Initialization In Elevator Subsystem
    m_SparkMaxElevatorEncoder = m_sparkElevatorLeft.getAlternateEncoder();

  //PID Controller Initialization In Elevator Subsystem
  //NOTE: These gains (kP, kI, kD) are starting points only. Tune kP up until the elevator
  //tracks setpoints quickly without oscillating, then add a tiny bit of kD if it overshoots.
    m_PidElevatorController = new PIDController(0.85, 0.0, 0.0);

  //How close (in encoder rotations) the elevator must get to a target position before we
  //consider it "at setpoint" and stop the scoring sequence from waiting on it.
    m_PidElevatorController.setTolerance(0.15);

  //Configuration Object Constructors: Elevator Motor Controllers And Elevator Encoder
    SparkMaxConfig sparkElevatorLeftConfig = new SparkMaxConfig();
    SparkMaxConfig sparkElevatorRightConfig = new SparkMaxConfig();
    EncoderConfig elevatorEncoderConfig = new EncoderConfig(); 

  //Configure Voltage Limiters On Both Elevator Motor Controllers. Constants Can Be Modified To Lower The Threshold Of Speed Applied By Motor Controllers
    m_sparkElevatorLeft.setVoltage(ElevatorConstants.elevator_SparkLeftCurrentLimit);
    m_sparkElevatorRight.setVoltage(ElevatorConstants.elevator_SparkRightCurrentLimit);

  //Configure Starting Speeds On Both Elevator Motor Controllers
    m_sparkElevatorLeft.set(0);
    m_sparkElevatorRight.set(0);

  //Configure Soft Limit On Left Motor Controller In Elevator Subsystem
    sparkElevatorLeftConfig.softLimit.forwardSoftLimitEnabled(true).forwardSoftLimit(ElevatorConstants.upperSoftLimit*12);
    sparkElevatorLeftConfig.softLimit.reverseSoftLimitEnabled(true).reverseSoftLimit(ElevatorConstants.lowerSoftLimit);

  //Configure Soft Limit On Right Motor Controller In Elevator Subsystem
    sparkElevatorRightConfig.softLimit.forwardSoftLimitEnabled(true).forwardSoftLimit(ElevatorConstants.upperSoftLimit*12);
    sparkElevatorRightConfig.softLimit.reverseSoftLimitEnabled(true).reverseSoftLimit(ElevatorConstants.lowerSoftLimit); 

  //Configure Right Elevator Motor Controller To Follow Left Elevator Motor Controller By Spinning Them In Opposite Directions (Inverted)
    sparkElevatorRightConfig.follow(ElevatorConstants.elevator_SparkLeftID, true);
    
  //Configure Break Mode On Both Motor Controllers To Hold Elevator In Place
    sparkElevatorLeftConfig.idleMode(IdleMode.kBrake);
    sparkElevatorRightConfig.idleMode(IdleMode.kBrake);

  //Elevator Encoder Configuration 
  sparkElevatorLeftConfig.alternateEncoder.countsPerRevolution(8192).setSparkMaxDataPortConfig().inverted(false);

  //PID Controller Configuration
    //sparkElevatorLeftConfig.closedLoop.pid(0.85,0.0000000000000015,0);

  //Confirm Elevator Motor Controller Configuration
    m_sparkElevatorLeft.configure(sparkElevatorLeftConfig, SparkBase.ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
    m_sparkElevatorRight.configure(sparkElevatorRightConfig, SparkBase.ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);

  }

  /**
   * This method is an example of the 'subsystem factory' style of command creation. A method inside
   * the subsytem is created to return an instance of a command. This works for commands that
   * operate on only that subsystem, a similar approach can be done in RobotContainer for commands
   * that need to span subsystems. The Subsystem class has helper methods, such as the startEnd
   * method used here, to create these commands.
   */

  public Command getClimbCommand() {
    // The startEnd helper method takes a method to call when the command is initialized and one to
    // call when it ends
    return this.startEnd(
        // When the command is initialized, set the wheels to the intake speed values
        () -> {
          setLeftClimb(ElevatorConstants.elevator_ClimbSpeed);
        },
        // When the command stops, stop the wheels
        () -> {
          stop();
        });
  }

  /**
   * This method is an example of the 'subsystem factory' style of command creation. A method inside
   * the subsytem is created to return an instance of a command. This works for commands that
   * operate on only that subsystem, a similar approach can be done in RobotContainer for commands
   * that need to span subsystems. The Subsystem class has helper methods, such as the startEnd
   * method used here, to create these commands.
   */
  public Command getDescendCommand() {
    // The startEnd helper method takes a method to call when the command is initialized and one to
    // call when it ends
    return this.startEnd(
        // When the command is initialized, set the wheels to the intake speed values
        () -> {
          setLeftClimb(Constants.ElevatorConstants.elevator_DescendSpeed);
        },
        // When the command stops, stop the wheels
        () -> {
          stop();
        });
  }

   /**
   * This method is an example of the 'subsystem factory' style of command creation. A method inside
   * the subsytem is created to return an instance of a command. This works for commands that
   * operate on only that subsystem, a similar approach can be done in RobotContainer for commands
   * that need to span subsystems. The Subsystem class has helper methods, such as the startEnd
   * method used here, to create these commands.
   */
   public Command getStopCommand() {
    // The startEnd helper method takes a method to call when the command is initialized and one to
    // call when it ends
    return this.startEnd(
        // When the command is initialized, set the wheels to the intake speed values
        () -> {
          setLeftClimb(0);
        },
        // When the command stops, stop the wheels
        () -> {
          stop();
        });
  }

  // An accessor method to set the speed (technically the output percentage) of the launch wheel
  public void setLeftClimb(double speed) {
    m_sparkElevatorLeft.set(speed);
    SmartDashboard.putNumber("leftClimber", speed);
    
  }

  /**
   * Drives the elevator toward a target height (given in encoder rotations) using the PID
   * controller, clamping the output so we never command full speed into the hard stops.
   */
  public void goToPosition(double targetRotations) {
    double currentRotations = m_SparkMaxElevatorEncoder.getPosition();
    double pidOutput = m_PidElevatorController.calculate(currentRotations, targetRotations);

    //Clamp PID output so the elevator can't slam into the top/bottom at full speed if the
    //PID gains are too aggressive or the setpoint is far away.
    pidOutput = MathUtil.clamp(pidOutput, -0.5, 0.5);

    setLeftClimb(pidOutput);
    SmartDashboard.putNumber("elevatorTargetRotations", targetRotations);
    SmartDashboard.putNumber("elevatorCurrentRotations", currentRotations);
  }

  /** True once the elevator is within tolerance of the last requested PID setpoint. */
  public boolean atSetpoint() {
    return m_PidElevatorController.atSetpoint();
  }

  /**
   * Command that drives the elevator to a given scoring position (see ElevatorPositions) and
   * finishes once it arrives. Use this before firing the coral mechanism so you're actually
   * lined up with the reef level you're trying to score on.
   */
  public Command goToPositionCommand(ElevatorPositions position) {
    return this.run(() -> goToPosition(position.getValueRotations()))
        .until(this::atSetpoint)
        .finallyDo((interrupted) -> setLeftClimb(0));
  }
 
  //TODO: Ask Mr. Kondo If This Method Can Be Merged With Climb Commands
  //Ensures Elevator Speed Returns To Zero Based On Alternate Encoder Position. Protects Elevator Overextension
  public void setLeftClimbDummy(double elevatorSpeed) {
    //Speed Will ONLY Be Passed If Elevator Is Within Given Elevator Encoder Position
    if (m_SparkMaxElevatorEncoder.getPosition() < ElevatorConstants.upperSoftLimit || m_SparkMaxElevatorEncoder.getPosition() > ElevatorConstants.lowerSoftLimit) 
    {
      m_sparkElevatorLeft.set(elevatorSpeed);
    }
    //Else Elevator Speed Is Set To 0
    else 
    {
      m_sparkElevatorLeft.set(0);
    }

  }

  // A helper method to stop both wheels. You could skip having a method like this and call the
  // individual accessors with speed = 0 instead
  public void stop() {
    m_sparkElevatorLeft.set(0);
    m_sparkElevatorRight.set(0);
  }

  public double getRotationsTravelDistance()
  {
    
    //The Starting Height Of The Elevator. Measured From The Top Face Of The Base Extrusion Of The Elevator To The Top Face Of The Top Extrusion On The Elevators Middle Stage
    double startingElevatorHeight = 35;

    //The Fully Extended Height Of The Elevator. Measured From The Top Face Of The Base Extrusion Of The Elevator To The Top Face Of The Top Extrusion On The Elevators Middle Stage
    double extendedElevatorHeight = 62;

    //The Difference Between The Elevator's Fully Extended Configuration And Starting Configuration. This Is The Vertical Distance Traveled Between The Elevator's Starting And Extended Configuration
    double travelDifference = extendedElevatorHeight - startingElevatorHeight;

    //Amount Of Rotations Elevator Sprockets Complete Before Reaching Fully Extended Elevator Height
    double maxElevatorSprocketRotations;

    //Radius Of Sprockets Driving Elevator Chains (Without The Gear's Teeth)
    double sprocketRadius = .819; 

    //Circumference Of Sprocket
    double sprocketCircumference = 2*Math.PI*sprocketRadius;
    
    //Calculate maxElevatorSprocketRotations. We Divide The Distance Traveled From Starting To Extended By The Circumference Of The Sprocket. 
    maxElevatorSprocketRotations = travelDifference / sprocketCircumference;
    
    //Returns Estimated Amount Of Elevator Sprocket Rotations Before The Elevator Reaches Its Fully Extended Height From Starting Configuration
    return maxElevatorSprocketRotations;
  }

//Elevator Positions (Copied From Other File)

public enum ElevatorPositions {
  // L1(10),
  // L2(45),
  // L3(64),
  // L4(91.25),
  // Barge(90.495417),
  // AlgaeReefHigh(54.5),
  // AlgaeReefLow(39),
  // Processor(23),
  // Stow(32),
  // CoralStation(30.5),
  // MaxHeight(94),
  // MinimumHeight(8);
  L1(2.04),
  L2(4.50),
  L3(6.50),
  L4(10.45),
  Barge(10.7),
  AlgaeReefHigh(5.15),
  AlgaeReefLow(3.2),
  Processor(3.5),
  Stow(4),
  CoralStation(3.18),
  MaxHeight(10.75),
  MinimumHeight(0);

  private final double value;

  ElevatorPositions(double value) {
      this.value = value;
  }

  public double getValueRotations() {
      // return 0.329911 * value - 1.92945;
      return value;
  }

  // public double getValueInches() {
  //     return value;
  // }
}

}

