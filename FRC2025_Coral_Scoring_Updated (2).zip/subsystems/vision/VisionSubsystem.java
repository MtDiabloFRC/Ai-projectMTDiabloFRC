// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems.vision;

import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.LimelightHelpers;

/**
 * Wraps the Limelight 3G + LimelightHelpers so the rest of the robot code doesn't need to know
 * about NetworkTables keys directly. Reads AprilTag (fiducial) target data each loop:
 *   - tv: whether a tag is currently visible
 *   - tx: horizontal angle offset from crosshair to target (negative = target is left)
 *   - ty: vertical angle offset from crosshair to target (used as a rough distance proxy)
 *   - fiducial ID: which AprilTag is being seen
 */
public class VisionSubsystem extends SubsystemBase {

  //This MUST match the name set in the Limelight web UI (Settings page). If you never changed
  //it, the default is "limelight".
  private static final String LIMELIGHT_NAME = "limelight";

  private boolean hasTarget = false;
  private double tx = 0.0;
  private double ty = 0.0;
  private double ta = 0.0;
  private double fiducialId = -1;

  public VisionSubsystem() {
  }

  @Override
  public void periodic() {
    hasTarget = LimelightHelpers.getTV(LIMELIGHT_NAME);
    tx = LimelightHelpers.getTX(LIMELIGHT_NAME);
    ty = LimelightHelpers.getTY(LIMELIGHT_NAME);
    ta = LimelightHelpers.getTA(LIMELIGHT_NAME);
    fiducialId = LimelightHelpers.getFiducialID(LIMELIGHT_NAME);

    SmartDashboard.putBoolean("Vision/HasTarget", hasTarget);
    SmartDashboard.putNumber("Vision/TX", tx);
    SmartDashboard.putNumber("Vision/TY", ty);
    SmartDashboard.putNumber("Vision/TA", ta);
    SmartDashboard.putNumber("Vision/FiducialID", fiducialId);
  }

  /** True if the Limelight currently sees an AprilTag. */
  public boolean hasTarget() {
    return hasTarget;
  }

  /** Horizontal offset (degrees) from crosshair to the tag. Negative = tag is to the left. */
  public double getTX() {
    return tx;
  }

  /** Vertical offset (degrees) from crosshair to the tag. Larger = tag appears higher/closer. */
  public double getTY() {
    return ty;
  }

  /** Target area as a percentage of the image (0-100). Bigger = closer to the tag. */
  public double getTA() {
    return ta;
  }

  /** ID number of the AprilTag currently being tracked, or -1 if none visible. */
  public double getFiducialId() {
    return fiducialId;
  }
}
