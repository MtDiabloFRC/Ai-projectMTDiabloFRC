// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import frc.robot.Constants.OperatorConstants;
import frc.robot.subsystems.coral.CoralSubsystem;
import frc.robot.subsystems.elevator.ElevatorSubsytem;
import frc.robot.subsystems.elevator.ElevatorSubsytem.ElevatorPositions;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;
import frc.robot.subsystems.vision.VisionSubsystem;
import frc.robot.commands.*;
import swervelib.SwerveInputStream;


/**
 * RobotContainer wires together all subsystems, controller bindings, and the autonomous chooser.
 *
 * ═══════════════════════════════════════════════════════════
 *  XBOX CONTROLLER MAP  (port 0)
 * ═══════════════════════════════════════════════════════════
 *  LEFT STICK        - Drive forward / strafe (field-oriented)
 *  RIGHT STICK X     - Rotate robot
 *
 *  A Button          - Align to AprilTag THEN auto-score (one-button full sequence)
 *  X Button          - Go to Coral Station intake position + run intake wheel
 *  Y Button          - Elevator Up (manual override)
 *  B Button          - Elevator Down (manual override)
 *
 *  LEFT BUMPER       - Shoot coral out (manual)
 *  RIGHT BUMPER      - Suck coral in (manual)
 *
 *  LEFT TRIGGER      - Stow elevator (go to safe travel height)
 *  RIGHT TRIGGER     - Hold to auto-rotate toward AprilTag (driver still steers)
 *
 *  D-PAD UP          - Score coral on L4
 *  D-PAD RIGHT       - Score coral on L3
 *  D-PAD LEFT        - Score coral on L2
 *  D-PAD DOWN        - Score coral on L1
 *
 *  START             - Zero gyroscope (recalibrate field-oriented drive)
 * ═══════════════════════════════════════════════════════════
 */
public class RobotContainer {

  // ── Controller ───────────────────────────────────────────────────────────
  final CommandXboxController driverXbox = new CommandXboxController(0);

  // ── Subsystems ───────────────────────────────────────────────────────────
  public final SwerveSubsystem  m_drivebase       = new SwerveSubsystem();
  private final ElevatorSubsytem m_elevator        = new ElevatorSubsytem();
  private final CoralSubsystem   m_CoralSubsystem  = new CoralSubsystem();
  private final VisionSubsystem  m_vision          = new VisionSubsystem();

  // ── Autonomous Level Chooser (shown on SmartDashboard / Shuffleboard) ────
  // Before the match, operators pick which reef level to score on in auto.
  private final SendableChooser<ElevatorPositions> autoLevelChooser = new SendableChooser<>();

  public RobotContainer() {
    // Build the auto level chooser and put it on SmartDashboard
    autoLevelChooser.setDefaultOption("L2 (2 pts)",         ElevatorPositions.L2);
    autoLevelChooser.addOption("L4 (Top - 3 pts)",         ElevatorPositions.L4);
    autoLevelChooser.addOption("L3 (3 pts)",               ElevatorPositions.L3);
    autoLevelChooser.addOption("L1 (1 pt)",                ElevatorPositions.L1);
    SmartDashboard.putData("Auto Scoring Level", autoLevelChooser);

    configureBindings();
  }

  private void configureBindings() {

    // ── Default drive command (field-oriented, angular velocity) ─────────
    m_drivebase.setDefaultCommand(driveFieldOrientedAngularVelocity);

    // ── Face buttons ─────────────────────────────────────────────────────

    // A: Align to AprilTag, THEN score at the level selected on SmartDashboard.
    // This is the "smart score" button — driver lines up roughly, presses A, robot does the rest.
    driverXbox.a().onTrue(
        new AlignToTagCommand(m_drivebase, m_vision)
            .andThen(() -> ScoringCommands.scoreCoral(
                m_elevator, m_CoralSubsystem, autoLevelChooser.getSelected()).schedule())
    );

    // X: Move elevator to coral station height and run the intake wheel.
    // Driver drives under the coral station, holds X to collect a piece.
    driverXbox.x().whileTrue(
        m_elevator.goToPositionCommand(ElevatorPositions.CoralStation)
            .andThen(m_CoralSubsystem.suckCoralCommand())
    );

    // Y: Manual elevator up (hold). Use if auto positioning isn't working.
    driverXbox.y().whileTrue(m_elevator.getClimbCommand());

    // B: Manual elevator down (hold).
    driverXbox.b().whileTrue(m_elevator.getDescendCommand());

    // ── Bumpers ──────────────────────────────────────────────────────────

    // Left Bumper: Manually shoot coral out (hold).
    driverXbox.leftBumper().whileTrue(m_CoralSubsystem.shootCoralCommand());

    // Right Bumper: Manually suck coral in (hold).
    driverXbox.rightBumper().whileTrue(m_CoralSubsystem.suckCoralCommand());

    // ── Triggers ─────────────────────────────────────────────────────────

    // Left Trigger: Stow the elevator to safe travel height.
    // Press after scoring so the robot can drive under the stage safely.
    driverXbox.leftTrigger(0.5).onTrue(
        m_elevator.goToPositionCommand(ElevatorPositions.Stow)
    );

    // Right Trigger: Hold to auto-rotate toward the AprilTag.
    // Driver still controls forward/strafe with the left stick — the trigger only corrects yaw.
    // Use this to aim at the reef before pressing D-pad to score.
    driverXbox.rightTrigger(0.5).whileTrue(new AlignToTagCommand(m_drivebase, m_vision));

    // ── D-Pad: One-button coral scoring at each level ─────────────────────
    // Drives elevator to height → shoots coral → returns to stow. No manual alignment needed
    // if driver is already close to the reef (use right trigger first for best accuracy).
    driverXbox.povUp().onTrue(
        ScoringCommands.scoreCoral(m_elevator, m_CoralSubsystem, ElevatorPositions.L4));
    driverXbox.povRight().onTrue(
        ScoringCommands.scoreCoral(m_elevator, m_CoralSubsystem, ElevatorPositions.L3));
    driverXbox.povLeft().onTrue(
        ScoringCommands.scoreCoral(m_elevator, m_CoralSubsystem, ElevatorPositions.L2));
    driverXbox.povDown().onTrue(
        ScoringCommands.scoreCoral(m_elevator, m_CoralSubsystem, ElevatorPositions.L1));

    // ── Misc ─────────────────────────────────────────────────────────────

    // Start: Reset gyroscope. Use at the start of a match or if field-oriented drive drifts.
    driverXbox.start().onTrue(Commands.runOnce(m_drivebase::zeroGyro));
  }

  /**
   * Called by Robot.java to get the autonomous command.
   * Runs AutoScoreCommand which: searches for an AprilTag → aligns → approaches → scores.
   * The level is whatever the drive team selected on SmartDashboard before the match.
   */
  public Command getAutonomousCommand() {
    return new AutoScoreCommand(
        m_drivebase,
        m_vision,
        m_elevator,
        m_CoralSubsystem,
        autoLevelChooser.getSelected()
    );
  }

  // ── Field-oriented swerve drive stream ───────────────────────────────────
  SwerveInputStream driveAngularVelocity = SwerveInputStream.of(m_drivebase.getSwerveDrive(),
      () -> driverXbox.getLeftY() * -1,
      () -> driverXbox.getLeftX() * -1)
      .withControllerRotationAxis(driverXbox::getRightX)
      .deadband(OperatorConstants.DEADBAND)
      .scaleTranslation(0.8)
      .allianceRelativeControl(true);

  Command driveFieldOrientedAngularVelocity = m_drivebase.driveFieldOriented(driveAngularVelocity);
}
