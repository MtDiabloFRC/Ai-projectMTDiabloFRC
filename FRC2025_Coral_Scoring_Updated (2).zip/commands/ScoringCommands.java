// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import frc.robot.subsystems.coral.CoralSubsystem;
import frc.robot.subsystems.elevator.ElevatorSubsytem;
import frc.robot.subsystems.elevator.ElevatorSubsytem.ElevatorPositions;

/**
 * Commands that combine the elevator and coral subsystems to actually score a coral piece.
 * Scoring a point on the reef requires two things to happen in order:
 *   1. Get the elevator to the correct height for the level you're scoring on (L1-L4)
 *   2. Run the coral outtake to push the piece off the mechanism and onto the reef
 * Doing this as one command means a driver/operator can press a single button instead of
 * having to manually drive the elevator up, wait, then separately hit the shoot button.
 */
public final class ScoringCommands {

  //How long to run the outtake wheel once the elevator is in position. Tune this so the
  //coral piece reliably clears the mechanism without spinning the wheel longer than needed.
  private static final double SHOOT_TIME_SECONDS = 0.5;

  /**
   * Drives the elevator to the requested scoring level, fires the coral piece once the
   * elevator arrives, then returns the elevator to the stowed position.
   *
   * @param elevator the elevator subsystem
   * @param coral    the coral subsystem
   * @param level    which reef level to score on (L1, L2, L3, or L4)
   */
  public static Command scoreCoral(ElevatorSubsytem elevator, CoralSubsystem coral, ElevatorPositions level) {
    return Commands.sequence(
        // Step 1: move the elevator up to the requested level and wait until it's there
        elevator.goToPositionCommand(level),
        // Step 2: run the outtake wheel just long enough to push the coral piece out
        coral.shootCoralCommand().withTimeout(SHOOT_TIME_SECONDS),
        // Step 3: bring the elevator back down to a safe stowed height
        elevator.goToPositionCommand(ElevatorPositions.Stow)
    ).withName("ScoreCoral_" + level.name());
  }

  /**
   * Same as scoreCoral, but does NOT automatically return to stow afterward. Useful if you
   * want the driver to manually bring the elevator down (e.g. so they can confirm the piece
   * actually scored before retracting).
   */
  public static Command scoreCoralAndHold(ElevatorSubsytem elevator, CoralSubsystem coral, ElevatorPositions level) {
    return Commands.sequence(
        elevator.goToPositionCommand(level),
        coral.shootCoralCommand().withTimeout(SHOOT_TIME_SECONDS)
    ).withName("ScoreCoralAndHold_" + level.name());
  }

  private ScoringCommands() {
    throw new UnsupportedOperationException("This is a utility class!");
  }
}
