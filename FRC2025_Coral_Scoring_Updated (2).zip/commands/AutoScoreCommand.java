// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import frc.robot.subsystems.coral.CoralSubsystem;
import frc.robot.subsystems.elevator.ElevatorSubsytem;
import frc.robot.subsystems.elevator.ElevatorSubsytem.ElevatorPositions;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;
import frc.robot.subsystems.vision.VisionSubsystem;

/**
 * Full autonomous scoring sequence:
 *   1. Wait up to SEARCH_TIMEOUT_SEC for the Limelight to see a reef AprilTag.
 *   2. Rotate in place until tx (horizontal offset) is within tolerance — robot is now facing the tag.
 *   3. Drive forward slowly until ta (target area) hits CLOSE_ENOUGH_AREA — robot is now at scoring distance.
 *   4. Score coral at the requested level using ScoringCommands.scoreCoral().
 *
 * The scoring level is chosen on SmartDashboard before the match via the auto chooser in
 * RobotContainer. If no tag is ever seen, the sequence times out and ends safely.
 */
public class AutoScoreCommand extends Command {

  // ── Tuning constants ──────────────────────────────────────────────────────
  /** How long (seconds) to spin looking for a tag before giving up. */
  private static final double SEARCH_TIMEOUT_SEC = 3.0;

  /** Rotation kP: degrees of tx error → rotation speed in rad/s. Tune on real robot. */
  private static final double ROTATION_KP = 0.05;

  /** Once tx is within this many degrees we consider yaw aligned. */
  private static final double YAW_TOLERANCE_DEG = 1.5;

  /** Drive-forward kP: (target area - current area) → forward speed m/s. Tune on real robot. */
  private static final double DRIVE_KP = 0.03;

  /**
   * Target area (% of image) that means "we're close enough to score."
   * Larger = closer to the tag. Start around 12-15 and tune — too small and
   * the robot will drive into the reef; too large and it scores from too far away.
   */
  private static final double CLOSE_ENOUGH_AREA = 13.0;

  /** Safety cap on forward drive speed so we don't ram the reef. */
  private static final double MAX_DRIVE_SPEED_MPS = 0.6;

  /** Safety cap on rotation speed. */
  private static final double MAX_ROT_SPEED = 2.0;

  /** Slow spin speed when searching for a tag (rad/s). */
  private static final double SEARCH_SPIN_SPEED = 0.5;
  // ─────────────────────────────────────────────────────────────────────────

  public enum AutoState {
    SEARCHING,    // Spinning slowly, waiting for a tag to appear
    ALIGNING,     // Tag found, rotating to center it
    APPROACHING,  // Aligned, driving forward to scoring distance
    SCORING,      // Running the elevator+coral scoring sequence
    DONE          // Finished or timed out
  }

  private final SwerveSubsystem drivebase;
  private final VisionSubsystem vision;
  private final ElevatorSubsytem elevator;
  private final CoralSubsystem coral;
  private final ElevatorPositions scoringLevel;

  private final PIDController rotationPID = new PIDController(ROTATION_KP, 0, 0);
  private final PIDController drivePID    = new PIDController(DRIVE_KP,    0, 0);

  private AutoState state = AutoState.SEARCHING;
  private Command scoringCommand = null;
  private double searchStartTime = 0;
  private double stateStartTime  = 0;

  public AutoScoreCommand(SwerveSubsystem drivebase,
                          VisionSubsystem vision,
                          ElevatorSubsytem elevator,
                          CoralSubsystem coral,
                          ElevatorPositions scoringLevel) {
    this.drivebase    = drivebase;
    this.vision       = vision;
    this.elevator     = elevator;
    this.coral        = coral;
    this.scoringLevel = scoringLevel;

    rotationPID.setTolerance(YAW_TOLERANCE_DEG);
    rotationPID.setSetpoint(0.0);

    // drivePID error = (CLOSE_ENOUGH_AREA - current ta), setpoint = 0 when error = 0
    drivePID.setTolerance(1.0);
    drivePID.setSetpoint(0.0);

    // We don't add elevator/coral as requirements here because ScoringCommands handles
    // their requirements internally when the scoring command is created.
    addRequirements(drivebase);
  }

  @Override
  public void initialize() {
    state          = AutoState.SEARCHING;
    scoringCommand = null;
    searchStartTime = edu.wpi.first.wpilibj.Timer.getFPGATimestamp();
    stateStartTime  = searchStartTime;
    rotationPID.reset();
    drivePID.reset();
    SmartDashboard.putString("Auto/State", state.name());
  }

  @Override
  public void execute() {
    double now = edu.wpi.first.wpilibj.Timer.getFPGATimestamp();

    switch (state) {

      case SEARCHING: {
        // If we've been searching too long, give up
        if (now - searchStartTime > SEARCH_TIMEOUT_SEC) {
          drivebase.drive(new Translation2d(0, 0), 0, false);
          state = AutoState.DONE;
          break;
        }
        if (vision.hasTarget()) {
          // Tag found — move straight into alignment
          state = AutoState.ALIGNING;
          stateStartTime = now;
          SmartDashboard.putString("Auto/State", state.name());
          break;
        }
        // Spin slowly to sweep the Limelight across the reef wall
        drivebase.drive(new Translation2d(0, 0), SEARCH_SPIN_SPEED, false);
        break;
      }

      case ALIGNING: {
        if (!vision.hasTarget()) {
          // Lost the tag — go back to searching
          state = AutoState.SEARCHING;
          SmartDashboard.putString("Auto/State", state.name());
          break;
        }
        double rotSpeed = MathUtil.clamp(
            rotationPID.calculate(vision.getTX()), -MAX_ROT_SPEED, MAX_ROT_SPEED);
        drivebase.drive(new Translation2d(0, 0), rotSpeed, false);

        if (rotationPID.atSetpoint()) {
          state = AutoState.APPROACHING;
          stateStartTime = now;
          SmartDashboard.putString("Auto/State", state.name());
        }
        break;
      }

      case APPROACHING: {
        if (!vision.hasTarget()) {
          state = AutoState.SEARCHING;
          SmartDashboard.putString("Auto/State", state.name());
          break;
        }

        double currentArea = vision.getTA();

        // Keep yaw corrected while approaching
        double rotSpeed = MathUtil.clamp(
            rotationPID.calculate(vision.getTX()), -MAX_ROT_SPEED * 0.5, MAX_ROT_SPEED * 0.5);

        if (currentArea >= CLOSE_ENOUGH_AREA) {
          // Close enough — stop driving and start scoring
          drivebase.drive(new Translation2d(0, 0), 0, false);
          state = AutoState.SCORING;
          stateStartTime = now;
          SmartDashboard.putString("Auto/State", state.name());

          // Build and schedule the scoring command now
          scoringCommand = ScoringCommands.scoreCoral(elevator, coral, scoringLevel);
          scoringCommand.schedule();
          break;
        }

        // Drive forward proportionally to how far we still need to go
        double forwardSpeed = MathUtil.clamp(
            DRIVE_KP * (CLOSE_ENOUGH_AREA - currentArea), 0, MAX_DRIVE_SPEED_MPS);
        drivebase.drive(new Translation2d(forwardSpeed, 0), rotSpeed, false);
        break;
      }

      case SCORING: {
        // The scoring command is running on the scheduler — we just wait for it to finish
        if (scoringCommand == null || !scoringCommand.isScheduled()) {
          state = AutoState.DONE;
          SmartDashboard.putString("Auto/State", state.name());
        }
        break;
      }

      case DONE:
        // Nothing to do
        drivebase.drive(new Translation2d(0, 0), 0, false);
        break;
    }

    SmartDashboard.putString("Auto/State", state.name());
    SmartDashboard.putString("Auto/ScoringLevel", scoringLevel.name());
    SmartDashboard.putBoolean("Auto/HasTag", vision.hasTarget());
    SmartDashboard.putNumber("Auto/TX", vision.getTX());
    SmartDashboard.putNumber("Auto/TA", vision.getTA());
  }

  @Override
  public void end(boolean interrupted) {
    drivebase.drive(new Translation2d(0, 0), 0, false);
    if (scoringCommand != null && scoringCommand.isScheduled()) {
      scoringCommand.cancel();
    }
    SmartDashboard.putString("Auto/State", interrupted ? "INTERRUPTED" : "DONE");
  }

  @Override
  public boolean isFinished() {
    return state == AutoState.DONE;
  }
}
