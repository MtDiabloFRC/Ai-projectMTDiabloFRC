// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;
import frc.robot.subsystems.vision.VisionSubsystem;

/**
 * Uses the Limelight's horizontal offset (tx) to rotate the robot so it's facing straight at
 * the AprilTag on the reef. This does NOT drive the robot forward/backward or strafe into
 * scoring position - it only corrects yaw. Pair it with the driver's own forward stick input,
 * or extend it later to also use ty/ta to control distance once you've tuned this part.
 *
 * Hold the bound button: while held, the robot rotates itself to face the tag. Release the
 * button (or lose sight of the tag) and it stops correcting, handing control back to the
 * driver's normal field-oriented drive command.
 */
public class AlignToTagCommand extends Command {

  private final SwerveSubsystem drivebase;
  private final VisionSubsystem vision;

  //Proportional-only controller turning "degrees off-center" into a rotation speed (rad/s).
  //NOTE: kP here is a starting point - tune it on the real robot. Too high = oscillates/shakes,
  //too low = aligns too slowly to be useful at the reef.
  private final PIDController rotationController = new PIDController(0.05, 0.0, 0.0);

  //Once tx is within this many degrees of 0, we consider the robot "aligned" and stop turning.
  private static final double ALIGNMENT_TOLERANCE_DEGREES = 1.5;

  //Safety clamp so a bad reading can't spin the robot at full speed.
  private static final double MAX_ROTATION_RADIANS_PER_SEC = 2.0;

  public AlignToTagCommand(SwerveSubsystem drivebase, VisionSubsystem vision) {
    this.drivebase = drivebase;
    this.vision = vision;
    addRequirements(drivebase);

    rotationController.setTolerance(ALIGNMENT_TOLERANCE_DEGREES);
    rotationController.setSetpoint(0.0);
  }

  @Override
  public void execute() {
    if (!vision.hasTarget()) {
      //No tag visible - don't move the drivetrain, just sit still until one is seen again.
      drivebase.drive(new Translation2d(0, 0), 0, false);
      return;
    }

    double currentTx = vision.getTX();
    double rotationSpeed = rotationController.calculate(currentTx);
    rotationSpeed = MathUtil.clamp(rotationSpeed, -MAX_ROTATION_RADIANS_PER_SEC, MAX_ROTATION_RADIANS_PER_SEC);

    //Rotation only - no translation. Translation field-relative flag doesn't matter here
    //since we're passing zero translation, but the swerve drive method requires it.
    drivebase.drive(new Translation2d(0, 0), rotationSpeed, true);
  }

  @Override
  public void end(boolean interrupted) {
    drivebase.drive(new Translation2d(0, 0), 0, false);
  }

  @Override
  public boolean isFinished() {
    //Ends once we're aligned AND a target is visible. If the tag disappears, this returns
    //false (controller's last setpoint check) so the command just keeps idling until the
    //driver releases the button.
    return vision.hasTarget() && rotationController.atSetpoint();
  }
}
