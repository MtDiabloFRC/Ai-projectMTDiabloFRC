package frc.robot.subsystems.coral;

import com.revrobotics.spark.SparkMax;
import com.revrobotics.spark.SparkBase;
import com.revrobotics.spark.SparkBase.PersistMode;
import com.revrobotics.spark.SparkBase.ResetMode;
import com.revrobotics.spark.config.SparkBaseConfig;
import com.revrobotics.spark.config.SparkMaxConfig;
import com.revrobotics.spark.SparkFlex;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.spark.SparkClosedLoopController;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;

import frc.robot.Constants;
import frc.robot.Constants.CoralSubsystemConstants;


public class CoralSubsystem extends SubsystemBase  {

//Coral Motor Controller Declaration
  SparkMax m_coralMotorController;

//Create Coral Subsytem Method
  public CoralSubsystem() { 

//Coral Motor Controller Initialization. 
   m_coralMotorController = new SparkMax(Constants.CoralSubsystemConstants.coral_SparkID, MotorType.kBrushless);

//Configuration Object Constructor
  SparkMaxConfig coralMotorControllerConfig = new SparkMaxConfig();

//Confirm Elevator Motor Controller Configuration
  m_coralMotorController.configure(coralMotorControllerConfig,ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);

}


/* Section For Coral Commands To Be Sent To RobotContainer File Below */

//Command For Shooting Coral OUT
public Command shootCoralCommand() { 
  return this.startEnd(
    // When the command is initialized, set the wheels to the intake speed values
    () -> {
      setCoralSpeed(Constants.CoralSubsystemConstants.coral_OutakeSpeed);
    },
    // When the command stops, stop the wheels
    () -> {
      stopCoral();
    });
}

// An accessor method to set the speed (technically the output percentage) of the launch wheel
  public void setCoralSpeed (double speed) {
    m_coralMotorController.set(speed);
    SmartDashboard.putNumber("colarSpeed", speed);
  }

  // A helper method to stop both wheels. You could skip having a method like this and call the
  // individual accessors with speed = 0 instead
  public void stopCoral() {
    m_coralMotorController.set(0);

  }

    //Command For Sucking Coral IN
    public Command suckCoralCommand() { 
      return this.startEnd(
        // When the command is initialized, set the wheels to the intake speed values
        () -> {
          setCoralSpeed(Constants.CoralSubsystemConstants.coral_IntakeSpeed);
        },
        // When the command stops, stop the wheels
        () -> {
          stopCoral();
        });
    }

}