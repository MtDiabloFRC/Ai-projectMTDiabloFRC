// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.math.util.Units;
import swervelib.math.Matter;

/**
 * The Constants class provides a convenient place for teams to hold robot-wide numerical or boolean constants. This
 * class should not be used for any other purpose. All constants should be declared globally (i.e. public static). Do
 * not put anything functional in this class.
 *
 * <p>It is advised to statically import this class (or one of its inner classes) wherever the
 * constants are needed, to reduce verbosity.
 */
public final class Constants
{

  public static final double ROBOT_MASS = (150) * 0.453592; // 32lbs * kg per pound
  public static final Matter CHASSIS    = new Matter(new Translation3d(0, 0, Units.inchesToMeters(8)), ROBOT_MASS);
  public static final double LOOP_TIME  = 0.13; //s, 20ms + 110ms sprk max velocity lag
  public static final double MAX_SPEED  = Units.feetToMeters(20);
  // Maximum speed of the robot in meters per second, used to limit acceleration.

//  public static final class AutonConstants
//  {
//
//    public static final PIDConstants TRANSLATION_PID = new PIDConstants(0.7, 0, 0);
//    public static final PIDConstants ANGLE_PID       = new PIDConstans(0.4, 0, 0.01);
//  }

  public static final class DrivebaseConstants
  {

    // Hold time on motor brakes when disabled
    public static final double WHEEL_LOCK_TIME = 10; // seconds
  }

  public static class OperatorConstants
  {

    // Joystick Deadband
    public static final double DEADBAND        = 0.3;
    public static final double LEFT_Y_DEADBAND = 0.3;
    public static final double RIGHT_X_DEADBAND = 0.3;
    public static final double TURN_CONSTANT    = 2;
    
    //JEFFERSON (12/28/24): Quick Fix- creating a deadband and turn speed variable to use them in drive commands in RobotContainer (Part 4) 
    
    public static final double LEFT_X_DEADBAND = 0.3;
    //mateo 1/15/25 - changed turnspeed to negitive as controls were inverted for yaw
    public static final double TurnSpeed = 1;
 

    
  
  }
  
  public final class ElevatorConstants {
    //CAN ID's For Elevator Motor Controllers [TODO: Make Sure These ID's Match On Rev Hardware Client]
    public static final int elevator_SparkLeftID = 9;
    public static final int elevator_SparkRightID = 10;

    //Speed Constants For Elevator Climb Speed (Up) And Descend Speed (Down)
    public static final double elevator_ClimbSpeed = .25;
    public static final double elevator_DescendSpeed = -.25;

    // Motor Electrical Current Limit Constants (To Limit Potential Speed Output To Protect Elevator)
    public static final int elevator_SparkLeftCurrentLimit = 80;
    public static final int elevator_SparkRightCurrentLimit = 80;

    //Soft Limits Constants For Elevator Subsystem 
    public static final double upperSoftLimit = 4.33; //How Many Times Axle Rotates Before Full Elevator Extension.
    public static final double lowerSoftLimit = 0;

    //Elevator Gearbox Ratio Constant
    public static final double elevatorGearBoxRatio = 12;

    }

  public final class CoralSubsystemConstants {
    //CAN ID For Coral Motor Controller
    public static final int coral_SparkID = 11;

    //Speed Constants For Coral Outake Speed (Shoot Coral Out) And Intake Speed (Suck Coral In)
    public static final double coral_OutakeSpeed = 0.3;
    public static final double coral_IntakeSpeed = -0.3;




  }

public static double maxSpeed = 3;

  }
