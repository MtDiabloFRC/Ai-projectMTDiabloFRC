// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.DriverStation.Alliance;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.InstantCommand;
import edu.wpi.first.wpilibj2.command.RunCommand;
import frc.robot.RobotContainer;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;
import swervelib.SwerveInputStream;

// import frc.robot.subsystems.CANDrivetrain;

public final class Autos {
  /** Example static factory for an autonomous command. */
  public static Command swerveAuto(SwerveSubsystem drivebase) {
    /**
     * RunCommand is a helper class that creates a command from a single method, in this case we
     * pass it the arcadeDrive method to drive straight back at half power. We modify that command
     * with the .withTimeout(1) decorator to timeout after 1 second, and use the .andThen decorator
     * to stop the drivetrain after the first command times out
     */

     // TODO:The speeds provided aren't correct, we need to use the left stick right stick speeds

    Translation2d translation2dMove = new Translation2d(0,-5);
    Translation2d translation2dStop = new Translation2d(0,0);
    ChassisSpeeds chasis = new ChassisSpeeds();
    chasis.vxMetersPerSecond = DriverStation.getAlliance().get() == Alliance.Red ? 0.5 : -0.5;
    chasis.vyMetersPerSecond = 0.0;
    chasis.omegaRadiansPerSecond = 0.0;
    return drivebase.driveFieldOriented(() -> chasis);
    // return new RunCommand(() -> drivebase.drive(translation2dMove, 0,true), drivebase)
    //     .withTimeout(5)
    //     .andThen(new RunCommand(() -> drivebase.drive(translation2dStop, 0, false), drivebase));
  }

  private Autos() {
    throw new UnsupportedOperationException("This is a utility class!");
  }
}
 