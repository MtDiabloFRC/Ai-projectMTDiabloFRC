package frc.robot.commands.swervedrive.drivebase;

//JEFFERSON (12/28/24): Import statements to create SwerveSubsystem
import java.io.File;
import java.util.function.DoubleSupplier;
import edu.wpi.first.wpilibj.Filesystem;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;
import swervelib.parser.SwerveParser;
import swervelib.SwerveDrive;
import swervelib.math.SwerveMath;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.util.Units;

public class SwerveSubsystem extends SubsystemBase {

//JEFFERSON (12/28/24): Creates the SwerveDrive (Part 3 Video)
 double maximumSpeed = Units.feetToMeters(4.5);
 File directory = new File(Filesystem.getDeployDirectory(), "swerve");
 SwerveDrive swerveDrive;

 //JEFFERSON (12/28/24): Exception handling. Source: https://github.com/BroncBotz3481/YAGSL-Example/blob/main/src/main/java/frc/robot/subsystems/swervedrive/SwerveSubsystem.java (Part 3 Video)
 public SwerveSubsystem() {

  try 
{
    swerveDrive = new SwerveParser(directory).createSwerveDrive(Constants.MAX_SPEED);
} catch (Exception e)
{
    throw new RuntimeException(e);
}
 }

 //JEFFERSON (12/28/24): Drive commands. Source: https://github.com/BroncBotz3481/YAGSL-Example/blob/main/src/main/java/frc/robot/subsystems/swervedrive/SwerveSubsystem.java (Part 4 Video)
public Command driveCommand(DoubleSupplier translationX, DoubleSupplier translationY, DoubleSupplier angularRotationX)
  {
    return run(() -> {
      // Make the robot move
      swerveDrive.drive(SwerveMath.scaleTranslation(new Translation2d(
                            translationX.getAsDouble() * swerveDrive.getMaximumChassisVelocity(),
                            translationY.getAsDouble() * swerveDrive.getMaximumChassisVelocity()), 0.8),
                        Math.pow(angularRotationX.getAsDouble(), 3) * swerveDrive.getMaximumChassisAngularVelocity(),
                        false,
                        false);
    });
  }
 }



